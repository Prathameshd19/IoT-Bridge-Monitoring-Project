package com.example.bridgemonitoring;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Login extends AppCompatActivity {
    EditText etcontact,etpassword;
    Button btn_login;
    TextView tv_register;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        tv_register=findViewById(R.id.tv_reg);
        etcontact=findViewById(R.id.edit_contact);
        etpassword=findViewById(R.id.edit_pass);
        btn_login=findViewById(R.id.btn_login);

        tv_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(Login.this,Register.class);
                startActivity(intent);
            }
        });

        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (etcontact.getText().toString().equals("1234567890")&& etpassword.getText().toString().equals("1234"))
                {
                    Toast.makeText(Login.this,"Login Succesfull",Toast.LENGTH_SHORT).show();
                    Intent intent=new Intent(Login.this,Dashboard.class);
                    startActivity(intent);
                }
                else {
                    Toast.makeText(Login.this,"Login Unsuccesfull",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}